function loler(){
    var gta = document.getElementById("lol").innerHTML;
    alert(gta);
}